import logo from './logo.svg';
import './App.css';
import ChatBox from './Components/ChatBox';
import TaskBoard from './Components/TaskBoard';

function App() {
  return (
    <div className="App">
     <ChatBox/>
     {/* <TaskBoard/> */}
    </div>
  );
}

export default App;
